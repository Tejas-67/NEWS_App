package com.example.repospect.API

class RetrofitInstance {
}